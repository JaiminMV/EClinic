export interface ZoomAuthToken {
  zoomToken: string;
  zoomPassword: string;
}
