export const PRIVATE_ROUTE = [
  "/me/family-member",
  "/me/profile-settings",
  "/me/appointments-list",
  "/me/health-records",
  "/me/manage-address",
  "/me/feedback-list",
  "/me/wallet-history",
  "/me/notification-list",
];
